package com.mkj.mains;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.mkj.beans.Accounts;

public class AccountMainAutoWire {

	public static void main(String[] args) {
		
		/* XML file available within resource package*/
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-autowire.xml");
		Accounts accounts = (Accounts)context.getBean("savingAccount");
		AccountsUtil.displayAccount(accounts);
	}
	
	

}
