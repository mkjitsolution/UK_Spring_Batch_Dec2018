package com.mkj.mains;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mkj.beans.Address;

public class AddressAnnotationMain {

	public static void main(String[] args) {
		
		ApplicationContext context = 
				new ClassPathXmlApplicationContext("spring-Annotation-config.xml");
		Address address = context.getBean(Address.class, "address");
		System.out.println(address);
		
	}
}
