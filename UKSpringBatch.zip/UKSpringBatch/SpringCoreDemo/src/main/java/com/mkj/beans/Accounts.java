package com.mkj.beans;

public class Accounts {
	
	private int balance;
	private long accountNumber;
	private int minBalance;
	private String accountHolderName;
	private Policy policy;

	public Accounts() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	
	public Accounts(int balance, long accountNumber, int minBalance, String accountHolderName, Policy policy) {
		super();
		this.balance = balance;
		this.accountNumber = accountNumber;
		this.minBalance = minBalance;
		this.accountHolderName = accountHolderName;
		this.policy = policy;
	}




	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public int getMinBalance() {
		return minBalance;
	}

	public void setMinBalance(int minBalance) {
		this.minBalance = minBalance;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}


	public Policy getPolicy() {
		return policy;
	}


	public void setPolicy(Policy policy) {
		this.policy = policy;
	}


	@Override
	public String toString() {
		return "Accounts [balance=" + balance + ", accountNumber=" + accountNumber + ", minBalance=" + minBalance
				+ ", accountHolderName=" + accountHolderName + ", policy=" + policy + "]";
	}

	


	
	
	

}
