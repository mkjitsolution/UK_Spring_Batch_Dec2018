package com.mkj.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.mkj.beans.Accounts;

@Configuration
public class AccountsConfig {

	
	@Bean
	public Accounts createAccount()
	{
		return new Accounts();
	}
	
	@Bean
	public Accounts createAccountProperty()
	{
		Accounts a = new Accounts();
		a.setAccountHolderName("Mike");
		a.setAccountNumber(5000);
		return a;
	}
	
	
}
