package com.mkj.mains;

import com.mkj.beans.Accounts;

public class AccountsUtil {

	public static  void displayAccount(Accounts accounts)
	{
		System.out.println(" Account Holder Name "+accounts.getAccountHolderName());
		System.out.println(" Account Number  "+accounts.getAccountNumber());
		System.out.println(" Balance "+accounts.getBalance());
		System.out.println(" Policy "+accounts.getPolicy());
	}
}
