package com.mkj.beans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("address.properties")
public class Address {

	@Value("123")
	private String houseNumber;
	@Value("Dubai")
	private String city;
	
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Address(String houseNumber, String city) {
		super();
		this.houseNumber = houseNumber;
		this.city = city;
	}
	public String getHouseNumber() {
		return houseNumber;
	}
	
	@Value("${mkj.address}")
	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}
	public String getCity() {
		return city;
	}
	@Value("${mkj.city}")
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Address [houseNumber=" + houseNumber + ", city=" + city + "]";
	}
	
}




