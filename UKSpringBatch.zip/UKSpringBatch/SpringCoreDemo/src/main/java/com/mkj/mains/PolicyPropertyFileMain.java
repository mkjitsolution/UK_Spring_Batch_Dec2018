package com.mkj.mains;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.mkj.beans.Accounts;
import com.mkj.beans.Policy;

public class PolicyPropertyFileMain {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-propertyfile.xml");
		Policy p = (Policy)context.getBean("policy");
		System.out.println(p);
		
	}
	
	

}
