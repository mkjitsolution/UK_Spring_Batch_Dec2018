package com.mkj.beans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("accounts.properties")
public class Accounts {

	@Value("${name}")
	private String accountName;
	@Value("${balance}")
	private int balance;
	
	// other bean standards
	
	public Accounts() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Accounts(String accountName, int balance) {
		super();
		this.accountName = accountName;
		this.balance = balance;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Accounts [accountName=" + accountName + ", balance=" + balance + "]";
	}
	
	
}
