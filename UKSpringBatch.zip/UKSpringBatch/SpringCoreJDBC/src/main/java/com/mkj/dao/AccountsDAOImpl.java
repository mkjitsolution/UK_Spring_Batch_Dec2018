package com.mkj.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.mkj.beans.Accounts;

@Component
@Scope("singleton")
public class AccountsDAOImpl {

	@Autowired
	private DataSource dataSource;
	private Connection con;
	
	@PostConstruct
	public void doInit()
	{
		try{
			con = dataSource.getConnection();
		}
		catch(Exception e)
		{ 	System.out.println(e);		}
	}
	
	// some more code ....
	
	
	
	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public AccountsDAOImpl() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public boolean doAddAccounts(Accounts a)throws Exception
	{
		PreparedStatement ps = con.prepareStatement("insert into Accounts values(?,?)");
		ps.setString(1,a.getAccountName());
		ps.setInt(2,a.getBalance());
		
		int i = ps.executeUpdate();
		if(i>0)return true;
		else return false;
		
	}
	
	
}
