package com.mkj.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mkj.beans.Accounts;
import com.mkj.dao.AccountsDAOImpl;

public class ClientCodeMain {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Accounts a = context.getBean("accounts",Accounts.class);
		AccountsDAOImpl dao = context.getBean("accountsDAOImpl",AccountsDAOImpl.class);
		boolean isInserted = false;
		try {
			isInserted = dao.doAddAccounts(a);
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println(isInserted);
		
	}
}
