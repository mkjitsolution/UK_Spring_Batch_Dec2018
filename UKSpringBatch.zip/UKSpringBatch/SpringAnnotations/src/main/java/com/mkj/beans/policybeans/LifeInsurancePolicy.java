package com.mkj.beans.policybeans;

import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("Policy.properties")
public class LifeInsurancePolicy implements Policy 
{
	private String policyName;
	private int policyTerm;
	private int premiumTerm;
	private int sumInsured;
	private String mode;
	private int premiumAmount;
	
	public LifeInsurancePolicy() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LifeInsurancePolicy(String policyName, 
			int policyTerm, int premiumTerm, 
			String mode) {
		super();
		this.policyName = policyName;
		this.policyTerm = policyTerm;
		this.premiumTerm = premiumTerm;
		this.mode = mode;
	}

	public int getPolicyTerm() {
		return policyTerm;
	}
	public void setPolicyTerm(int policyTerm) {
		this.policyTerm = policyTerm;
	}
	public int getPremiumTerm() {
		return premiumTerm;
	}
	public void setPremiumTerm(int premiumTerm) {
		this.premiumTerm = premiumTerm;
	}
	public int getSumInsured() {
		return sumInsured;
	}
	public void setSumInsured(int sumInsured) {
		this.sumInsured = sumInsured;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public int getPremiumAmount() {
		return premiumAmount;
	}
	public void setPremiumAmount(int premiumAmount) {
		this.premiumAmount = premiumAmount;
	}
	@Override
	public int calculatePremiumAmount() {
		premiumAmount = (int)(sumInsured*0.8);
		return premiumAmount;
	}

	@Override
	public String toString() {
		return "LifeInsurancePolicy [policyName=" + policyName + ", policyTerm=" + policyTerm + ", premiumTerm="
				+ premiumTerm + ", sumInsured=" + sumInsured + ", mode=" + mode + ", premiumAmount=" + premiumAmount
				+ "]";
	}
	
}
