package com.mkj.beans;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.mkj.beans.policybeans.Policy;

@Component
@PropertySource("Accounts.properties")
@Scope("prototype")
public class Accounts {
	
	private int balance;
	private long accountNumber;
	@Value("${minBalance}")
	private int minBalance;
	private String accountHolderName;
	
	@Autowired
	@Qualifier("mediClaimPolicy")
	private Policy policy;

	public Accounts() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println(" accounts constructor called");
	}
	@PostConstruct
	public void doInit()
	{
		System.out.println("do init called");
	}
	@PreDestroy
	public void doWrapup()
	{
		System.out.println(" do wrapup called");
	}
	
	public Accounts(int balance, long accountNumber, int minBalance, String accountHolderName, Policy policy) {
		super();
		this.balance = balance;
		this.accountNumber = accountNumber;
		this.minBalance = minBalance;
		this.accountHolderName = accountHolderName;
		this.policy = policy;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public int getMinBalance() {
		return minBalance;
	}

	public void setMinBalance(int minBalance) {
		this.minBalance = minBalance;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}


	public Policy getPolicy() {
		return policy;
	}


	public void setPolicy(Policy policy) {
		this.policy = policy;
	}


	@Override
	public String toString() {
		return "Accounts [balance=" + balance + ", accountNumber=" + accountNumber + ", minBalance=" + minBalance
				+ ", accountHolderName=" + accountHolderName + ", policy=" + policy + "]";
	}


	

}
