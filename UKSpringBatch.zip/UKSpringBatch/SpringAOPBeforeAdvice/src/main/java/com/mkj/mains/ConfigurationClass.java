package com.mkj.mains;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@ComponentScan("com.mkj.aspect")
@ComponentScan("com.mkj.beans")
@ComponentScan("com.mkj.beans.policybeans")
@ComponentScan("com.mkj.mains")
@EnableAspectJAutoProxy
public class ConfigurationClass {

}
