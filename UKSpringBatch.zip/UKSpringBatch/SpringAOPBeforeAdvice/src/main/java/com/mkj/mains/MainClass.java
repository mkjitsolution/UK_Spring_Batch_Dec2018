package com.mkj.mains;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mkj.beans.Accounts;
import com.mkj.beans.policybeans.MediClaimPolicy;

public class MainClass {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring-Annotation-config.xml");
		
		Accounts a = context.getBean("accounts",Accounts.class);
		a.setBalance(65000);
		System.out.println(a);
		System.out.println("=========================");
		System.out.println(a.getMinBalance());
		
		System.out.println("=========================");
		System.out.println(a.getBalance());
		
		System.out.println("=========================");
		
		
		
		
		
		context.close();
		System.out.println("context closed");
	}
}
