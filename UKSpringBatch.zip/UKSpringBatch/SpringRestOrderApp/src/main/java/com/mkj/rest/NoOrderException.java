package com.mkj.rest;

public class NoOrderException extends Exception {

	public NoOrderException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoOrderException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
