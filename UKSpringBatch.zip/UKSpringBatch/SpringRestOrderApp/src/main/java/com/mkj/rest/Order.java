package com.mkj.rest;

import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

//@JsonIgnoreProperties(ignoreUnknown=true)
// @XmlRootElement  // for xml type
public class Order {
	
	private int orderNumber;
	private String customerName;
	private String customerAddress;
	private String product;
	private int cost;
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Order(int orderNumber, String customerName, String customerAddress, String product, int cost) {
		super();
		this.orderNumber = orderNumber;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.product = product;
		this.cost = cost;
	}
	public int getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	@Override
	public String toString() {
		return "Order [orderNumber=" + orderNumber + ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + ", product=" + product + ", cost=" + cost + "]";
	}
	
	
	
}
