package com.mkj.rest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler
	public ResponseEntity<OrderErrorResponse> orderException(InvalidOrderIDException ex) {
		OrderErrorResponse errorResponse = new OrderErrorResponse();

		errorResponse.setMsg(ex.getMessage());
		errorResponse.setStatusCode(HttpStatus.NOT_FOUND.value());

		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler
	public ResponseEntity<OrderErrorResponse> orderException(Exception ex) {
		OrderErrorResponse errorResponse = new OrderErrorResponse();

		errorResponse.setMsg(ex.getMessage());
		errorResponse.setStatusCode(HttpStatus.BAD_REQUEST.value());

		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);

	}
	
	@ExceptionHandler
	public ResponseEntity<OrderErrorResponse> orderException(NoOrderException ex) {
		OrderErrorResponse errorResponse = new OrderErrorResponse();

		errorResponse.setMsg(ex.getMessage());
		errorResponse.setStatusCode(HttpStatus.NOT_FOUND.value());

		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

}
