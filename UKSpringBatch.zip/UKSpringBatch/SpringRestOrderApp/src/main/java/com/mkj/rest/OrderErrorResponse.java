package com.mkj.rest;

public class OrderErrorResponse {

	private String msg;
	private int statusCode;
	public OrderErrorResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OrderErrorResponse(String msg, int statusCode) {
		super();
		this.msg = msg;
		this.statusCode = statusCode;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	
	
}
